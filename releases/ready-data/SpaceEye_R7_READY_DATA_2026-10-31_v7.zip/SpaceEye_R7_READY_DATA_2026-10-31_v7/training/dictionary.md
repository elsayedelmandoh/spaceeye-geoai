# Expanded data contract

Synthetic - for training only

| Column | Role | Type |
| --- | --- | --- |
| code | key | str |
| developer_code | key | str |
| quarter | key | str |
| month | key | str |
| cover_ratio | X | float64 |
| cover_req0 | X | float64 |
| cover_ctc | X | float64 |
| land_late | X | float64 |
| cmp_rate90 | X | float64 |
| cmp_pctl | X | float64 |
| gap | X | float64 |
| report_age | X | float64 |
| meters | X | float64 |
| kwh_per_meter | X | float64 |
| kwh_ratio | X | float64 |
| d_cover_ratio | X | float64 |
| d_cover_ctc | X | float64 |
| d_land_late | X | float64 |
| d_cmp_rate90 | X | float64 |
| d_gap | X | float64 |
| d_meters | X | float64 |
| d_kwh_ratio | X | float64 |
| A | X | float64 |
| active | X | float64 |
| K2 | X | float64 |
| K3 | X | float64 |
| level | X | float64 |
| started | X | float64 |
| d_A | X | float64 |
| d_K2 | X | float64 |
| qi | key | int64 |
| K4 | X | bool |
| K5_months | X | Int64 |
| K6 | X | Int64 |
| may_be_complete | X | bool |
| observed_started | X | bool |
| start_observation_sufficient | X | bool |
| K1 | X | float64 |
| veg_share | X | float64 |
| height_mean_m | X | float64 |
| planned_pct | X | float64 |
| reported_pct | X | float64 |
| K5_egp | X | Float64 |
| activity_prob | X | float64 |
| land_months_late | X | float64 |
| y_outcome_6m | target/evaluation only | str |
| label_distress_next_6m | target/evaluation only | boolean |
| label_censored | target/evaluation only | bool |
| already_completed_at_cutoff | target/evaluation only | bool |
| synthetic_label | target/evaluation only | str |
