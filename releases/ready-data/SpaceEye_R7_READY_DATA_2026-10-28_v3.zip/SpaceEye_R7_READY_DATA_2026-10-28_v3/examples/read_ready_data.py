from pathlib import Path
import json
import duckdb
import pandas as pd

root = Path(__file__).resolve().parents[1]
with duckdb.connect(str(root / "spaceeye_ready.duckdb"), read_only=True) as con:
    print(con.execute("SELECT * FROM inspection_cycle_list ORDER BY cycle_rank").df())
meta = json.loads((root / "training/metadata.json").read_text(encoding="utf-8"))
data = pd.read_parquet(root / meta["dataset"])
mask = data.quarter.le("2024Q4") & ~data.label_censored & ~data.already_completed_at_cutoff
X_train = data.loc[mask, meta["features"]]
y_train = data.loc[mask, "label_distress_next_6m"]
print("Ready data:", len(data), "rows; X_train:", X_train.shape, "; binary positives:", int(y_train.sum()))
print("No model fitting performed. Inspect missingness and fit preprocessing on train only.")
