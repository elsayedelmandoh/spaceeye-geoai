# Included table dictionaries

These describe the included final tables only. No rejected or raw table is distributed.

- [real_compounds](real__compounds.md)
- [real_sat_quarterly](real__sat_quarterly.md)
- [real_sat_yearly](real__sat_yearly.md)
- [real_statements](real__statements.md)
- [real_eval_outcomes](real__eval_outcomes.md)
- [real_drivers_monthly](real__drivers_monthly.md)
- [real_rules](real__rules.md)
- [real_kpi_values](real__kpi_values.md)
- [operations_fin_monthly](sim_clean__fin_monthly.md)
- [operations_fin_quarterly](sim_clean__fin_quarterly.md)
- [operations_complaints](sim_clean__complaints.md)
- [operations_fine_assumptions](sim_clean__fine_assumptions.md)
- [financial_paths_initial_state](scenarios__initial_state.md)
- [financial_paths_paths](scenarios__paths.md)
- [review_synthetic_visits](component_data__synthetic_visits.md)
- [review_hypothetical_priorities](component_data__hypothetical_priorities.md)
- [data_completion/inspection_capacity](data_completion__inspection_capacity.md)
- [scenarios/summary](scenarios__summary.md)
