import csv
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
with (root / "MANIFEST.csv").open(encoding="utf-8", newline="") as stream:
    rows = list(csv.DictReader(stream))
for row in rows:
    path = (root / row["file"]).resolve()
    assert root in path.parents, "Unexpected path"
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row["sha256"], row["file"]
print("PASS:", len(rows), "package files match SHA-256 manifest")
