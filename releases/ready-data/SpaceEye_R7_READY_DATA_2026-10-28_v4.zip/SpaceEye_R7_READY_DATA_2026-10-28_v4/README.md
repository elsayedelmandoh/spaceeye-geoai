# SpaceEye ready-to-use team data

Release: 28 October 2026. Scope: 12 coded compounds in R7.
Generated operations and hypothetical financial paths are labelled: Synthetic - for training only.

## Quick start

1. Extract the complete archive to any folder on your computer.
2. Open `spaceeye_ready.duckdb` directly. It contains observation tables, prepared operations, financial paths and inspection selections.
3. Alternatively, read Parquet files under `tables/`. UTF-8 CSV copies are under `csv/`; inspection lists and the financial summary are CSV files alongside their tables.
4. `TABLES.csv` lists table names, file locations and row counts. Column definitions are under `dictionaries/`.
5. For modelling, use `training/ml_dataset_extended.parquet` with `training/metadata.json`. The training export is separate from the application database, and its targets are not features.

## Contents

- Observations and indicators: 12 compounds, 516 quarterly observations, 132 annual rows, 372 indicator rows and 57 published statements.
- Prepared operations: 540 monthly financial rows, 180 financial quarters, 1,334 complaints with phone masking, and 12 synthetic allocation/fine-assumption records.
- Hypothetical financial paths: 648 rows, initial states, comparison summary and declared assumptions.
- Inspection selections: baseline capacity 4, with alternatives 2 and 6. The visit template is empty; no visit outcomes were invented.
- Training export: 180 rows and 40 declared features, with binary and three-class targets kept separate from X.
- Complaint classification:100labeled masked texts from the existing feed with conservative group splits,plus a SEPARATE296-text generated five-class capability benchmark. Use the benchmark alone for balanced capability work;do not combine the corpora or claim real complaint accuracy.
- Inspection inputs:180cutoff-safe JSON contexts under `inspection/inspection_contexts/`,indexed in `inspection/index.csv`. Public facts and generated operations/visits are separated;no hidden targets are agent inputs. Missing imagery is marked rather than fabricated.
- Review extensions:`tables/review/synthetic_visits.parquet` has58generated exercise visits,not actual fieldwork. `hypothetical_priorities.parquet` has648financial-path priority rows with same-month baseline comparisons,using the declared frozen-context/projected-B5rule.

## Run the example

From the extracted bundle folder, using the project's locked environment:

```powershell
uv run --project "path/to/spaceeye-geoai" python examples/read_ready_data.py
uv run --project "path/to/spaceeye-geoai" python verify_package.py
```

Alternatively, use an existing Python environment containing pandas, pyarrow and duckdb:

```powershell
python examples/read_ready_data.py
python verify_package.py
```

This bundle is standalone for reading, analysis and interface development. It does not require the original F: drive or raw-source downloads. It is not a complete input archive for rebuilding the source-acquisition pipeline.

## Definitions and limits

- X is exactly the `features` list in the training metadata. Keys, targets, `label_censored` and `already_completed_at_cutoff` are not features.
- Training ends at 2024Q4; 2025Q1 is embargoed; the time test is 2025Q2–2026Q1. The final two quarters have incomplete future horizons and must be excluded from supervised fitting and target metrics.
- The three-class target requires new full-project handover within the next six months; partial handover is insufficient. Distress takes precedence. There are zero completed training examples and one completed test example, so this export does not establish a reliable three-class classifier.
- K5 is a research-policy screening proxy. Fine amounts, the illustrative 1% monthly rate and allocation records are generated assumptions, not assessed fines or verified contracts. Relief is an optional hypothetical case gated by the news publication date, not automatic entitlement.
- Retrospectively generated allocation dates do not enter X or replace public K6. Insufficient observation remains unknown; do not automatically replace missing values with zero.
- Monthly unit sales are flows and are summed over each quarter. The training complaint diagnostic is normalized by cutoff-month sales, not cumulative sold inventory or buyer incidence.
- Financial paths are hypothetical, not handover-date forecasts. Historical N=8 early-warning results do not evaluate current capacity 4 or the expanded dataset.
- The 2019Q2 coverage flag and other limitations remain recorded in `docs/validation_summary.json`; passing package-integrity checks does not remove them.

Raw inputs, quarantined/rejected observations, hidden answer keys, code-to-name mappings and models are excluded. Parquet is authoritative for types and null values; CSV is provided for convenient viewing. Original Arabic complaint text is data and remains unchanged.

Every distributed file has a SHA-256 entry in `MANIFEST.csv`. Run `verify_package.py` after extraction to check transfer integrity. Version4 adds Arabic committee reasons, full Track A reproducibility, current model diagnostics, explained real-case checks and S1/S2/S3 handoff. `current_ml_current` contains conditional observed-class probabilities; `p_completed` is null because training has no completed examples. See docs/EW_REPORT_CURRENT.md and docs/SCENARIO_CONTRACT_CURRENT.md before using current outputs. Earlier prepared v3 remains a separate historical version.
